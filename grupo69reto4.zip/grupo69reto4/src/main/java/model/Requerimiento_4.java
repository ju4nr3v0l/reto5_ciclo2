package model;

public class Requerimiento_4 {
    private String abrev;


    public Requerimiento_4(){

    }

    public Requerimiento_4(Integer numeroProyectos) {
        this.abrev = abrev;
    }

    public String getAbrev() {
        return abrev;
    }

    public void setAbrev(String abrev) {
        this.abrev = abrev;
    }
}
