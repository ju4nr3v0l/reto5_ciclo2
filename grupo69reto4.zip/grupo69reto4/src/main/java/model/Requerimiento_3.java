package model;

public class Requerimiento_3 {
    private Integer numeroProyectos;


    public Requerimiento_3(){

    }

    public Requerimiento_3(Integer numeroProyectos) {
        this.numeroProyectos = numeroProyectos;
    }

    public Integer getNumeroProyectos() {
        return numeroProyectos;
    }

    public void setNumeroProyectos(Integer numeroProyectos) {
        this.numeroProyectos = numeroProyectos;
    }
}
