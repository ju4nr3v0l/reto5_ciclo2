package view;
import model.Requerimiento_2;

import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;

public class ModelDataTable2 extends AbstractTableModel {
    private String[] columnNames = {"Fec. Ini.","Nom. Ciudad","Nombre. Constructora","Nom. Lider","C. Tipo","Estrato"};
    private ArrayList<Requerimiento_2> datos;

    public ModelDataTable2(ArrayList<Requerimiento_2> datos) {
       this.datos = datos;
    }

    @Override
    public int getRowCount() {
        int size;
        if (datos == null) {
            size = 0;
        }
        else {
            size = datos.size();
        }
        return size;
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public Object getValueAt(int row, int col) {
        Object temp = null;
        if (col == 0) {
            temp = datos.get(row).getFechaInicio();
        }
        else if (col == 1) {
            temp = datos.get(row).getNombreCiudad();
        }
        else if (col == 2) {
            temp = datos.get(row).getConstructora();
        }
        else if (col == 3) {
            temp = datos.get(row).getLider();
        }
        else if (col == 4) {
            temp = datos.get(row).getTipo();
        }
        else if (col == 5) {
            temp = datos.get(row).getEstrato();
        }
        return temp;
    }

    public String getColumnName(int col) {
        return columnNames[col];
    }
    public Class getColumnClass(int col) {

        return String.class;

    }

}

