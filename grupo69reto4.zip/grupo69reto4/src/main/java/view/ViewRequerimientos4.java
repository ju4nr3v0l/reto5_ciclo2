package view;

import dao.ControllerRequerimientos;
import model.Requerimiento_4;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;

public class ViewRequerimientos4 extends  JFrame implements ActionListener {
    public static final ControllerRequerimientos controlador = new ControllerRequerimientos();
    private ModelDataTable4 tableModel;
    private JTable table;
    public ViewRequerimientos4(String title) throws SQLException {
        super(title);
        setBounds(10,10,480,380);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ArrayList<Requerimiento_4> listarRequerimiento4;
        listarRequerimiento4 = controlador.consultaRequerimiento4();
        tableModel = new ModelDataTable4(listarRequerimiento4);
        table = new JTable(tableModel);
        table.setAutoCreateRowSorter(true);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setPreferredSize(new Dimension(480,380));
        JPanel panel = new JPanel();
        panel.add(scrollPane);
        add(panel,BorderLayout.CENTER);
    }


    @Override
    public void actionPerformed(ActionEvent e) {

    }
}
