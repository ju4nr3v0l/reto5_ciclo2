package view;

import dao.ControllerRequerimientos;
import model.Requerimiento_2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;

public class ViewRequerimientos2 extends  JFrame implements ActionListener {
    public static final ControllerRequerimientos controlador = new ControllerRequerimientos();
    private ModelDataTable2 tableModel;
    private JTable table;
    public ViewRequerimientos2(String title) throws SQLException {
        super(title);
        setBounds(10,10,580,480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ArrayList<Requerimiento_2> listarRequerimiento2;
        listarRequerimiento2 = controlador.consultaRequerimiento2();
        tableModel = new ModelDataTable2(listarRequerimiento2);
        table = new JTable(tableModel);
        table.setAutoCreateRowSorter(true);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setPreferredSize(new Dimension(580,480));
        JPanel panel = new JPanel();
        panel.add(scrollPane);
        add(panel,BorderLayout.CENTER);
    }


    @Override
    public void actionPerformed(ActionEvent e) {

    }
}
