package view;

import dao.ControllerRequerimientos;
import model.Requerimiento_3;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;

public class ViewRequerimientos3 extends  JFrame implements ActionListener {
    public static final ControllerRequerimientos controlador = new ControllerRequerimientos();
    private ModelDataTable3 tableModel;
    private JTable table;
    public ViewRequerimientos3(String title) throws SQLException {
        super(title);
        setBounds(10,10,480,380);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ArrayList<Requerimiento_3> listarRequerimiento3;
        listarRequerimiento3 = controlador.consultaRequerimiento3();
        tableModel = new ModelDataTable3(listarRequerimiento3);
        table = new JTable(tableModel);
        table.setAutoCreateRowSorter(true);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setPreferredSize(new Dimension(480,380));
        JPanel panel = new JPanel();
        panel.add(scrollPane);
        add(panel,BorderLayout.CENTER);
    }


    @Override
    public void actionPerformed(ActionEvent e) {

    }
}
