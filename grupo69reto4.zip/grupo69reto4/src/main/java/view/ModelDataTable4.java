package view;
import model.Requerimiento_4;

import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;

public class ModelDataTable4 extends AbstractTableModel {
    private String[] columnNames = {"Abrev."};
    private ArrayList<Requerimiento_4> datos;

    public ModelDataTable4(ArrayList<Requerimiento_4> datos) {
       this.datos = datos;
    }

    @Override
    public int getRowCount() {
        int size;
        if (datos == null) {
            size = 0;
        }
        else {
            size = datos.size();
        }
        return size;
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public Object getValueAt(int row, int col) {
        Object temp = null;
        if (col == 0) {
            temp = datos.get(row).getAbrev();
        }

        return temp;
    }

    public String getColumnName(int col) {
        return columnNames[col];
    }
    public Class getColumnClass(int col) {

        return String.class;

    }

}

