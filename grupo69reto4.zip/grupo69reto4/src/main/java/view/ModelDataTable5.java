package view;
import model.Requerimiento_5;

import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;

public class ModelDataTable5 extends AbstractTableModel {
    private String[] columnNames = {"Constructora","Salario Lider"};
    private ArrayList<Requerimiento_5> datos;

    public ModelDataTable5(ArrayList<Requerimiento_5> datos) {
       this.datos = datos;
    }

    @Override
    public int getRowCount() {
        int size;
        if (datos == null) {
            size = 0;
        }
        else {
            size = datos.size();
        }
        return size;
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public Object getValueAt(int row, int col) {
        Object temp = null;
        if (col == 0) {
            temp = datos.get(row).getConstructora();
        }
        else if (col == 1) {
            temp = datos.get(row).getSalarioLider();
        }

        return temp;
    }

    public String getColumnName(int col) {
        return columnNames[col];
    }
    public Class getColumnClass(int col) {

        return String.class;

    }

}

