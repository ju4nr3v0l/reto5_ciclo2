package view;

import dao.ControllerRequerimientos;
import model.Requerimiento_1;
import model.Requerimiento_2;
import model.Requerimiento_3;
import model.Requerimiento_4;
import model.Requerimiento_5;

import java.awt.*;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class ViewRequerimientos1 extends  JFrame implements ActionListener {
    public static final ControllerRequerimientos controlador = new ControllerRequerimientos();
    private ModelDataTable1 tableModel;
    private JTable table;
    public ViewRequerimientos1(String title) throws SQLException {
        super(title);
        setBounds(10,10,480,380);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ArrayList<Requerimiento_1> listarRequerimiento1;
        listarRequerimiento1 = controlador.consultaRequerimiento1();
        tableModel = new ModelDataTable1(listarRequerimiento1);
        table = new JTable(tableModel);
        table.setAutoCreateRowSorter(true);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setPreferredSize(new Dimension(480,380));
        JPanel panel = new JPanel();
        panel.add(scrollPane);
        add(panel,BorderLayout.CENTER);
    }


    @Override
    public void actionPerformed(ActionEvent e) {

    }
}
