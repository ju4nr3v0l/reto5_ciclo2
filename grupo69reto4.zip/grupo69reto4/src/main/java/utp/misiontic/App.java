package utp.misiontic;

import view.ViewRequerimientos1;
import view.ViewRequerimientos2;
import view.ViewRequerimientos3;
import view.ViewRequerimientos4;
import view.ViewRequerimientos5;

import java.sql.SQLException;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) throws SQLException {



        ViewRequerimientos1 req1 = new ViewRequerimientos1("Consulta 1");
        req1.setVisible(true);
        ViewRequerimientos2 req2 = new ViewRequerimientos2("Consulta 2");
        req2.setVisible(true);
        ViewRequerimientos3 req3 = new ViewRequerimientos3("Consulta 3");
        req3.setVisible(true);
        ViewRequerimientos4 req4 = new ViewRequerimientos4("Consulta 4");
        req4.setVisible(true);
        ViewRequerimientos5 req5 = new ViewRequerimientos5("Consulta 5");
        req5.setVisible(true);

    }
}
